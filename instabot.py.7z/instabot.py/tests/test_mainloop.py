def test_mainloop(bot):
    bot.mainloop()