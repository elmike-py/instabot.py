from .instabot import InstaBot

__all__ = ['InstaBot']
__version__ = '0.7.18'
